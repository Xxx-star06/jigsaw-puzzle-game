# _*_ coding: utf-8
# @Time : 2025/7/13 09:17
# @Author Xxx
# @File : main

import sys
from PyQt5.QtWidgets import QApplication, QWidget
from view.LoginWidget import LoginWidget


if __name__ == '__main__':
    app = QApplication(sys.argv)
    LoginWidget = LoginWidget()
    LoginWidget.show()
    sys.exit(app.exec_())

# 后续要做的项目：拼图游戏、智慧工地、工地门禁系统