# _*_ coding: utf-8
# @Time : 2025/7/7 16:19
# @Author Xxx
# @File : file_io
def file_add(path, data):
    '''
    文件追加
    :param path: 文件路径
    :param data: 追加数据
    :return:
    '''

    try:
        with open(path, 'a+', encoding='UTF-8') as file:  # as 是取的名字
            line = ''
            # 解析输入的data
            for k, v in data.items():  # items()方法返回一个包含字典中所有键值对的列表
                line += f'{k}:{v}  '
            line = line[:-1] + '\n'  # 去掉最后一个空格，并换行
            file.write(line)
    except FileNotFoundError as e:
        print(f'文件{path}不存在，请检查路径是否正确')
        #做对应处理
        #创建一个新文件
    except PermissionError as e:
        print(f'文件{path}权限不足，请检查权限是否正确')
    except Exception as e:
        print(f'文件{path}操作失败，原因：{e}')


def file_read(path):
    '''
    文件数据的读取
    :param path: 文件路径
    文件读取
    :return:

    '''
    try:
        new_users = []
        with open(path, 'r', encoding='UTF-8') as file:
            for line in file.readlines():
                line = line.strip()  # 去掉两边的空格
                # print(line)
                # 把里面的数据获取出来重新组装成新的字典
                l1 = line.split()  # 不写默认是空格
                user = {}
                for l2 in l1:
                    print(l2)  # sid:123
                    l3 = l2.split(':')  # 按：分割
                    print(l3)  # ['sid', '123']
                    user[l3[0]] = l3[1]  # 配置为字典格式  stu1['pwd'] = '123312'
                new_users.append(user)  # 把字典添加到集合中
            return new_users
    except Exception as e:
        print(e)
    finally:
        print('每次都是执行')



