# _*_ coding: utf-8
# @Time : 2025/7/13 10:32
# @Author Xxx
# @File : game.py
import random
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import QWidget, QLabel, QPushButton, QGridLayout, QHBoxLayout, QVBoxLayout, QApplication


class Game(QWidget):
    def __init__(self, width=1000, height=700):  #self是类的实例化对象，width和height是窗口的大小
        super().__init__()
        self.width = width
        self.height = height

        self.init_win()
        self.init_win_item()  # 内容选项的实例化

    def init_win(self):
        '''
        :return:
        '''
        self.setWindowTitle('拼图游戏')
        self.setFixedSize(self.width, self.height)  # 修改为self.width和self.height
        self.setWindowIcon(QIcon('./images/img3_login.png'))  # 这个地方要注意，关于上下级

    def init_win_item(self):
        '''
        主界面是横向布局，分两块
        左边是网格，右边是垂直
        :return:
        '''
        # 主布局的设置和创建
        self.totalLayout = QHBoxLayout()
        self.setLayout(self.totalLayout)

        # 左边的网格布局
        self.left = QGridLayout()
        self.totalLayout.addLayout(self.left)

        # 右边的垂直布局
        self.right = QVBoxLayout()
        self.totalLayout.addLayout(self.right)  # addLayout是用于添加布局的函数，与addWidget不同，addLayout可以添加多个布局.widget是添加组件



    #随机空白一个 i和j是随机的一个
        self.m = random.randint(0,2)
        self.n = random.randint(0,2)


    #创建一个Qlabel图片对象的列表
        self.labs = []


    #创建一个随机列表
        self.random_list = random.sample(range(1, 10), 9)  #随机产生不重复的 1-9的9个数
        print(self.random_list)






        # 左侧网格布局
        for i in range(3):
            for j in range(3):
                self.gmp = QLabel()
                #因为在测试的情况下，程序的入口是Game，图是在上一级，所以用../
                self.gmp.setPixmap(QPixmap(f'./images/{self.random_list[i*3+j]}.png'))

                #把图片对象存储在列表
                self.labs.append(self.gmp)
                if i == self.m and j == self.n:
                    continue
                self.left.addWidget(self.gmp, i, j)  # 修改为self.left.addWidget

        # 右侧垂直布局
        self.movebtn = QPushButton('变换位置', self)
        self.restbtn = QPushButton('重新开始', self)
        self.exitbtn = QPushButton('退出游戏', self)

        self.right.addWidget(self.movebtn)
        self.right.addWidget(self.restbtn)
        self.right.addWidget(self.exitbtn)


    #鼠标点击操作
    def mousePressEvent(self, event):
        '''
        鼠标按下出发的事件 qt的默认事件 方法名不能改
        :param event: 被点击的对象
        :return:
        '''
        print(event.button())  # 打印鼠标点击的位置
        #button不是界面的按钮，而是鼠标的按钮 左键1 右键2  4键是滚轮
        print(Qt.LeftButton) # 打印鼠标左键的常量值
        if event.button() == Qt.LeftButton:
            #左键点击
            x = event.x()  # 鼠标点击的x坐标
            y = event.y()
            print(x,y)
            #把坐标转为行和列
            i = int((y + 75) / 300)
            j = int((x - 5) / 300)
            print(f'点击的是第{i}行第{j}列********空白的位置为{self.m},{self.n}')
            # 行不变，列变到行变，列不变
            if i == self.m and j == self.n - 1 or i == self.m and self.n + 1 or \
                    i == self.m - 1 and j == self.n or i == self.m + 1 and j == self.n:
                #交换位置
                #找到被点击图片对象，放入空白的位置
                self.left.addWidget(self.labs[i*3+j], self.m, self.n)
                #交换对象列表
                templab = self.labs[self.m*3+self.n]
                self.labs[self.m*3+self.n] = self.labs[i*3+j]
                self.labs[i*3+j] = templab
                #更新以下显示用的random_list
                temp = self.random_list[i*3+j]
                self.random_list[i*3+j] = self.random_list[self.m*3+self.n]
                self.random_list[self.m*3+self.n] = temp

                #更新空白位置
                self.m = i
                self.n = j
                print(f'空白位置更新为{self.m},{self.n}')
            else:
                print('不能移动')









if __name__ == '__main__':
    app = QApplication(sys.argv)
    game = Game()  # 修改为Game()
    game.show()  # 修改为gam.show()
    sys.exit(app.exec_())
