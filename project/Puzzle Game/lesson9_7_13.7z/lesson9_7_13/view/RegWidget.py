# _*_ coding: utf-8
# @Time : 2025/7/11 19:00
# @Author Xxx
# @File : RegWidget
import os
import sys

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon, QPalette, QBrush, QPixmap
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QPushButton, QApplication, QHBoxLayout, QVBoxLayout


# from PyQt5.QtWidgets import *  不推荐，会让程序启动变慢

class RegWidget(QWidget):
    # RegWidget 全局变量
    regback_Signal = pyqtSignal() #空参的信号
    regback_Signal2 = pyqtSignal(str) #带简单字符串的信号
    regback_Signal3 = pyqtSignal(dict) #带多个值组合成的字典的信号
    comfire_register_Signal = pyqtSignal(dict) #带多个值组合成的字典的信号




    def __init__(self, w = 600, h = 500):
        super().__init__()
        self.total_layout = None
        self.w = w
        self.h = h
        #外观初始化
        self.init_win()
        self.init_control()




    def init_win(self):
        self.setWindowTitle('账号注册')
        self.setFixedSize(self.w, self.h)
        self.setWindowIcon(QIcon('./images/img3_login.png'))  #这个地方要注意，关于上下级
        #背景
        # 设置背景
        palette = QPalette()
        # 设置图片和窗口一样大小
        palette.setBrush(self.backgroundRole(), QBrush(QPixmap('./images/img2.png').scaled(self.size())))
        self.setPalette(palette)



    def init_control(self):
        #相对布局
        #水平布局  被布局包含的子控件是沿x方向水平排布
        #垂直布局  被布局包含的子控件是沿y方向排布
        #实例化布局

        #主体布局
        # self.top_layout = QHBoxLayout()#水平布局
        self.total_layout = QVBoxLayout()#垂直布局
        self.setLayout(self.total_layout) #设置主布局

        #第一个
        self.line1 = QHBoxLayout() #水平布局
        self.total_layout.addLayout(self.line1) #把第一行添加到总布局

        #创建第一行的组件
        self.acclable = QLabel('用户名：',self)
        self.acclable.setStyleSheet("font-size:18px;color:red;")
        self.accEdit = QLineEdit(self)
        self.accEdit.setPlaceholderText('请输入账号')
        self.accEdit.setStyleSheet("font-size:18px;color:black;")
        #把组件加入到line1布局中
        self.line1.addWidget(self.acclable)
        self.line1.addWidget(self.accEdit)
        self.line1.setContentsMargins(100,0,100,0) #对应顺时针方向 左上右下
        #第二行
        self.line2 = QHBoxLayout()
        self.total_layout.addLayout(self.line2)
        self.pwdlabel = QLabel('密  码：',self)
        self.pwdlabel.setStyleSheet("font-size:18px;color:red;")
        self.pwdEdit = QLineEdit(self)
        self.pwdEdit.setPlaceholderText('请输入密码')
        self.pwdEdit.setEchoMode(QLineEdit.Password) #密码模式
        #把组件加入到line2布局中
        self.line2.addWidget(self.pwdlabel)
        self.line2.addWidget(self.pwdEdit)
        self.line2.setContentsMargins(100, 0, 100, 0)  #外边距
        #第三行
        self.line3 = QHBoxLayout()
        self.total_layout.addLayout(self.line3)
        self.repwdlabel = QLabel('确认密码：',self)
        self.repwdlabel.setStyleSheet("font-size:18px;color:red;")
        self.repwdEdit = QLineEdit(self)
        self.repwdEdit.setPlaceholderText('请确认密码')
        self.repwdEdit.setEchoMode(QLineEdit.Password) #密码模式
        #把组件加入到line3布局中
        self.line3.addWidget(self.repwdlabel)
        self.line3.addWidget(self.repwdEdit)
        self.line3.setContentsMargins(100, 0, 100, 0)  #外边距
        #第四行
        self.line4 = QHBoxLayout()
        #self.line4.setAlignment(Qt)
        self.total_layout.addLayout(self.line4)
        self.back_loginbtn = QPushButton('返回',self)
        self.back_loginbtn.setFixedSize(100,40)
        self.registerbtn = QPushButton('确认',self)
        self.registerbtn.setFixedSize(100,40)
        #相对布局默认是居中的
        #把组件加入到line4布局中
        self.line4.addWidget(self.back_loginbtn)
        self.line4.addWidget(self.registerbtn)

        #信号槽
        self.back_loginbtn.clicked.connect(self.back_login)
        self.registerbtn.clicked.connect(self.comfire_register)

    def back_login(self):
        #自己隐藏
        self.hide()
        #返回登录页面
        #可以给登录发一个信号，让它自己显示
        self.regback_Signal.emit() #发射信号，让登录自己显示 谁获取谁就能显示
        self.regback_Signal2.emit('hello') #发射信号，带参数
        user = {'sid':'ai250626','name':'xxx'}
        self.regback_Signal3.emit(user)


    def comfire_register(self):
        #隐藏注册窗口，返回登录窗口
        self.hide()
        #返回注册界面中的用户名和密码
        username = self.accEdit.text()
        password = self.pwdEdit.text()
        #将用户名和密码做成字典形式，发射信号，让登录界面显示
        user = {'username':username,'password':password}
        #并将账号和密码保存在文件夹中
        file_path = 'data/users.txt'
        try:
            if os.path.exists(file_path):
                with open(file_path,'a') as f:
                    f.write(username+' '+password+'\n')
            else:
                with open(file_path,'w') as f:
                    f.write(username+' '+password+'\n')
        except Exception as e:
            print(e)
        self.comfire_register_Signal.emit(user) #发射信号，让登录自己显示 谁获取谁就能显示










if __name__ == '__main__':   #创建应用

    app = QApplication(sys.argv)   #创建QApplication对象
    #实例化登录窗口
    reg = RegWidget()
    reg.show() #用于显示窗口
    #保持窗口显示，知道点击关闭按钮
    sys.exit(app.exec_())



