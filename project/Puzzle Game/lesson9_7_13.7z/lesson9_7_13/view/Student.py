# _*_ coding: utf-8
# @Time : 2025/7/7 17:54
# @Author Xxx
# @File : Student

class Student(object):
    count = 0
    def __init__(self,acc, name, pwd):
        Student.id = Student.count + 1000
        Student.count += 1
        self.name = name
        self.acc = acc
        self.pwd = pwd

    def show(self):
        print("User name: ", self.name)

    def login(self,acc,pwd):
        print("USERBEAN===========>User login")
        if self.acc == acc and self.pwd == pwd:
            print("登录成功")
            return 1
        else:
            print("登录失败")
            return None





