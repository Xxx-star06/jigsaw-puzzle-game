# _*_ coding: utf-8 _*_
# @Time : 2025/7/12 16:19
# @Author : Xxx
# @File : GameWidget.py

from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import QWidget, QLabel, QPushButton, QGridLayout

# 游戏主界面
class GameWidget(QWidget):

    def __init__(self, w=1400, h=900):
        super().__init__()  # surper的括号不要漏了
        # 宽 高 标题
        self.w = w
        self.h = h
        # 设置窗口属性
        self.resize(self.w, self.h)
        self.setWindowTitle('登录窗口')
        self.setWindowIcon(QIcon('../images/img3_login.png'))  # ./表示当前目录，可以不写，../表示上一级目录
        self.init_win()

    def init_win(self):
        # 初始化界面
        # 创建网格布局
        self.grid = QGridLayout()
        self.grid.setSpacing(10)  # 设置网格间隔

        # 创建按钮
        self.btn1 = QPushButton('移形换影')
        self.btn2 = QPushButton('重新来过')
        self.btn3 = QPushButton('游戏说明')
        self.btn4 = QPushButton('退出')

        # 设置按钮大小
        self.btn1.setFixedSize(150, 50)
        self.btn2.setFixedSize(150, 50)
        self.btn3.setFixedSize(150, 50)
        self.btn4.setFixedSize(150, 50)

        # 将按钮添加到布局中，放在最右边一列，垂直排列
        self.grid.addWidget(self.btn1, 0, 3, 1, 1)  # 第0行第3列，占1行1列
        self.grid.addWidget(self.btn2, 1, 3, 1, 1)  # 第1行第3列，占1行1列
        self.grid.addWidget(self.btn3, 2, 3, 1, 1)  # 第2行第3列，占1行1列
        self.grid.addWidget(self.btn4, 3, 3, 1, 1)  # 第3行第3列，占1行1列

        # 左边3*3的网格用于放图片
        self.img1 = QLabel(self)
        self.img1.setPixmap(QPixmap('../images/img1.png'))
        self.img2 = QLabel(self)
        self.img2.setPixmap(QPixmap('../images/img1.png'))
        self.img3 = QLabel(self)
        self.img3.setPixmap(QPixmap('../images/img1.png'))
        self.img4 = QLabel(self)
        self.img4.setPixmap(QPixmap('../images/img1.png'))
        self.img5 = QLabel(self)
        self.img5.setPixmap(QPixmap('../images/img1.png'))
        self.img6 = QLabel(self)
        self.img6.setPixmap(QPixmap('../images/img1.png'))
        self.img7 = QLabel(self)
        self.img7.setPixmap(QPixmap('../images/img1.png'))
        self.img8 = QLabel(self)
        self.img8.setPixmap(QPixmap('../images/img1.png'))
        self.img9 = QLabel(self)
        self.img9.setPixmap(QPixmap('../images/img1.png'))

        # 将图片添加到布局中
        self.grid.addWidget(self.img1, 0, 0, 1, 1)  # 第0行第0列，占1行1列
        self.grid.addWidget(self.img2, 0, 1, 1, 1)  # 第0行第1列，占1行1列
        self.grid.addWidget(self.img3, 0, 2, 1, 1)  # 第0行第2列，占1行1列
        self.grid.addWidget(self.img4, 1, 0, 1, 1)  # 第1行第0列，占1行1列
        self.grid.addWidget(self.img5, 1, 1, 1, 1)  # 第1行第1列，占1行1列
        self.grid.addWidget(self.img6, 1, 2, 1, 1)  # 第1行第2列，占1行1列
        self.grid.addWidget(self.img7, 2, 0, 1, 1)  # 第2行第0列，占1行1列
        self.grid.addWidget(self.img8, 2, 1, 1, 1)  # 第2行第1列，占1行1列
        self.grid.addWidget(self.img9, 2, 2, 1, 1)  # 第2行第2列，占1行1列

        # 设置主窗口的布局
        self.setLayout(self.grid)

