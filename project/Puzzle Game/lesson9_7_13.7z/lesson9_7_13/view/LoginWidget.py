# _*_ coding: utf-8
# @Time : 2025/7/8 15:45
# @Author Xxx
# @File : loginWidget
from PyQt5.QtGui import QIcon, QPalette, QBrush, QPixmap
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QPushButton, QMessageBox

from . import file_io as file  # 相对导入
#from .RegWidget import RegWidget  # 确保路径正确
from .RegWidget import RegWidget  # 确保路径正确 相对导入
from view.Student import Student
from view.Game import Game
from view.Code import Code


class LoginWidget(QWidget):
    def __init__(self, w = 700, h = 450 ):
        super().__init__()  #surper的括号不要漏了
        #宽 高 标题
        self.w = w
        self.h = h
        self.file_path = './data/users.txt'
        #设置窗口属性
        self.resize(self.w, self.h)
        self.setWindowTitle('登录窗口')
        self.setWindowIcon(QIcon('./images/img3_login.png')) #./表示当前目录，可以不写，../表示上一级目录

        #设置背景

        palette = QPalette()
        # 设置图片和窗口一样大小
        palette.setBrush(self.backgroundRole(), QBrush(QPixmap('images/img2.png').scaled(self.size())))
        self.setPalette(palette)

        self.regwidget = RegWidget() #实例化注册页面
        self.Game = Game() #实例化游戏页面

        self.init_win_item()

        self.init_data(self.file_path) #初始化数据


    def init_win_item(self):
        """
        初始化控件
        文本： 账号、密码
        输入框：文本输入
        密码框、按钮
        布局：
            绝对布局(默认布局：以左上角为原点向下和向右进行定位)

        return: None
        """
        #文本框
        self.acclable = QLabel('账号',self) #实例化一个文本
        #设置文本的位置和大小
        self.acclable.setGeometry(120, 70, 200, 40) #x,y,w,h
        self.acclable.setStyleSheet('color:red;font-size:28px')

        #输入框 文本编辑器
        self.accEdit = QLineEdit(self)
        self.accEdit.setGeometry(240, 70, 350, 40) #x,y,w,h
        self.accEdit.setPlaceholderText('请输入账号')  #提示文字
        self.accEdit.setStyleSheet('color:red;font-size:28px')
        self.accEdit.setMaxLength(20) #最大字符
        #验证码
        self.codeEdit = QLineEdit(self)
        self.codeEdit.setGeometry(120, 250, 200, 40)
        self.codeEdit.setPlaceholderText('验证码')
        self.codeEdit.setStyleSheet('color:red;font-size:28px')
        self.codeEdit.setMaxLength(4) #最大字符
        #验证码按钮
        self.code =Code(self)
        self.code.setGeometry(450, 250, 300, 40)

        #密码
        self.pwdBtn = QLabel('密码',self)
        self.pwdBtn.setGeometry(120, 130, 200, 40)
        self.pwdBtn.setStyleSheet('color:red;font-size:28px')
        self.pwdEdit = QLineEdit(self)
        self.pwdEdit.setGeometry(240, 130, 350, 40)
        self.pwdEdit.setPlaceholderText('请输入密码')
        self.pwdEdit.setStyleSheet('color:red;font-size:28px')
        self.pwdEdit.setMaxLength(20)
        self.pwdEdit.setEchoMode(QLineEdit.Password) #密码模式


        #按钮
        #登录和注册
        self.loginBtn = QPushButton('登录', self)
        self.loginBtn.setGeometry(120, 330, 100, 40) #x,y,w,h
        self.loginBtn.setStyleSheet('color:red;font-size:28px')

        self.resBtn = QPushButton('注册', self)
        self.resBtn.setGeometry(400, 330, 100, 40)
        self.resBtn.setStyleSheet('color:red;font-size:28px')

        #按钮方法的绑定 信号槽
        #信号------->槽
        self.resBtn.clicked.connect(self.toReg) #点击以后连接connect方法自定义的toReg方法
        self.loginBtn.clicked.connect(self.login) #点击以后连接connect方法自定义的get_input方法

        #获取信号
        self.regwidget.regback_Signal.connect(self.regback) #注册页面返回登录页面
        self.regwidget.regback_Signal2.connect(self.regback_str) #注册页面返回登录页面
        self.regwidget.regback_Signal3.connect(self.regback_dict) #注册页面返回登录页面
        #注册界面确认按钮的绑定
        self.regwidget.comfire_register_Signal.connect(self.comfire_register) #注册页面返回登录页面







    def init_data(self,path):
        '''
        初始化数据
        :param path: 文件路径
        :return:
        '''
        users = file.file_read(path)
        #将人员数据转为对象数据
        self.users_list = []
        for user in users:
            stu = Student(user['acc'], user['name'], user['pwd'])
            self.users_list.append(stu)
        print(self.users_list)







    def login(self):
        #获取输入框的值
        acc = self.accEdit.text()
        print(acc)
        pwd = self.pwdEdit.text()
        #在文件中查询账号密码是否正确
        '''
        file_path = './data/users.txt'
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    user_info = line.strip().split(' ')
                    if user_info[0] == acc and user_info[1] == pwd:
                        print('登录成功')
                        break
                    else:
                        print('登录失败')
                        break
        except FileNotFoundError:
            print('文件不存在')'''
        print(self.code.text)
        for user in self.users_list:
            if user.acc == acc and user.pwd == pwd:
                QMessageBox.information(self, '提示', '登录成功')
                self.hide() #隐藏登录页面
                self.Game.show() #显示游戏页面
                return
            else:
                QMessageBox.information(self, '提示', '登录失败~~~')
                self.pwdEdit.setText('') #清空密码框
                self.code.setText('') #清空验证码框







    #自定义的槽函数
    def toReg(self):
        print('跳转到注册去')
        #先隐藏登录页面
        self.hide()
        #显示注册页面
        print(self.regwidget.h, self.regwidget.w)
        self.regwidget.show() #显示注册页面




    def regback(self):
        print('regback**********')
        self.show() #显示登录页面



    def regback_str(self,str):
        print('regback********************str',str)


    def regback_dict(self,dict):
        print('regback**********dict',dict)

    def comfire_register(self,dict):
        print('comfire_register**********dict',dict)
        #将账号和密码在登录页面显示出来
        self.accEdit.setText(dict['username'])
        self.pwdEdit.setText(dict['password'])
        self.show() #显示登录页面


